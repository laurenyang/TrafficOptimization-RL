setup for env
